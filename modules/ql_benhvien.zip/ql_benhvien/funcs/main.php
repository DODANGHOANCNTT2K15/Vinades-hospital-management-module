<?php
if (!defined('NV_IS_MOD_QLBENHVIEN')) die('Stop!!!');

$op = $nv_Request->get_string('op', 'get', 'main');

switch ($op) {
    case 'dat_lich':
        include __DIR__ . '/booking.php';
        break;
    default:
        // trang chính module
        $contents = '<h2>QL Bệnh viện</h2>';
        $contents .= '<p><a href="' . NV_BASE_SITEURL . 'index.php?nv=' . $module_name . '&op=dat_lich">Đặt lịch khám</a></p>';
        include NV_ROOTDIR . '/includes/header.php';
        echo nv_site_theme($contents);
        include NV_ROOTDIR . '/includes/footer.php';
        break;
}
