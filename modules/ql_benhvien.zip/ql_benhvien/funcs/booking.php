<?php
if (!defined('NV_IS_MOD_QLBENHVIEN')) die('Stop!!!');

global $db, $db_config, $lang_module, $nv_Request;

// bảng
$table_doc = $db_config['prefix'] . "_" . NV_LANG_DATA . "_ql_benhvien_doctors";
$table_app = $db_config['prefix'] . "_" . NV_LANG_DATA . "_ql_benhvien_appointments";

// lấy danh sách bác sĩ
$docs = $db->query("SELECT id, fullname, specialty FROM " . $table_doc)->fetchAll();

$notice = '';
if ($nv_Request->isset_request('submit', 'post')) {
    $doctor_id = $nv_Request->get_int('doctor_id', 'post', 0);
    $patient_name = $nv_Request->get_title('patient_name', 'post', '');
    $patient_phone = $nv_Request->get_title('patient_phone', 'post', '');
    $patient_email = $nv_Request->get_title('patient_email', 'post', '');
    $date = $nv_Request->get_string('date', 'post', '');
    $time = $nv_Request->get_string('time', 'post', '');

    if (qlbenhvien_is_timeslot_free($doctor_id, $date, $time)) {
        $stmt = $db->prepare("INSERT INTO " . $table_app . " (doctor_id, patient_name, patient_phone, patient_email, appointment_date, appointment_time) VALUES (:doctor_id, :patient_name, :patient_phone, :patient_email, :date, :time)");
        $stmt->bindValue(':doctor_id', $doctor_id, PDO::PARAM_INT);
        $stmt->bindValue(':patient_name', $patient_name, PDO::PARAM_STR);
        $stmt->bindValue(':patient_phone', $patient_phone, PDO::PARAM_STR);
        $stmt->bindValue(':patient_email', $patient_email, PDO::PARAM_STR);
        $stmt->bindValue(':date', $date, PDO::PARAM_STR);
        $stmt->bindValue(':time', $time, PDO::PARAM_STR);
        $stmt->execute();
        $notice = '<p class="text-success">Đặt lịch thành công. Chờ xác nhận từ bệnh viện.</p>';
    } else {
        $notice = '<p class="text-danger">Thời gian này đã có lịch. Vui lòng chọn thời gian khác.</p>';
    }
}

// build form html (đơn giản)
$contents = '<h2>Đặt lịch khám trực tuyến</h2>' . $notice;
$contents .= '<form method="post">';
$contents .= '<label>Bác sĩ:</label><br><select name="doctor_id">';
foreach ($docs as $d) {
    $contents .= '<option value="' . $d['id'] . '">' . htmlspecialchars($d['fullname']) . ' - ' . htmlspecialchars($d['specialty']) . '</option>';
}
$contents .= '</select><br>';
$contents .= '<label>Họ tên bệnh nhân:</label><br><input name="patient_name" required><br>';
$contents .= '<label>Điện thoại:</label><br><input name="patient_phone"><br>';
$contents .= '<label>Email:</label><br><input name="patient_email" type="email"><br>';
$contents .= '<label>Ngày khám:</label><br><input type="date" name="date" required><br>';
$contents .= '<label>Giờ khám:</label><br><input type="time" name="time" required><br><br>';
$contents .= '<button type="submit" name="submit">Đặt lịch</button>';
$contents .= '</form>';

include NV_ROOTDIR . '/includes/header.php';
echo nv_site_theme($contents);
include NV_ROOTDIR . '/includes/footer.php';
