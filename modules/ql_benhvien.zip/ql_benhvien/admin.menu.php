<?php
if (!defined('NV_ADMIN')) die('Stop!!!');

$submenu['main'] = 'Tổng quan';
$submenu['schedule'] = 'Quản lý lịch khám';

$allow_func = [];
$allow_func[] = 'main';
$allow_func[] = 'schedule';
