<?php
if (!defined('NV_SYSTEM')) die('Stop!!!');

define('NV_IS_MOD_QLBENHVIEN', true);

/**
 * Kiểm tra timeslot có trống hay không (đơn giản: kiểm tra trùng exact time)
 * @param int $doctor_id
 * @param string $date YYYY-mm-dd
 * @param string $time HH:MM:SS (hoặc HH:MM)
 * @param int $duration (phút) - hiện chưa dùng để check khoảng, có thể nâng sau
 * @return bool true nếu trống
 */
function qlbenhvien_is_timeslot_free($doctor_id, $date, $time, $duration = 30)
{
    global $db, $db_config, $lang, $module_name;

    $table = $db_config['prefix'] . "_" . $lang . "_ql_benhvien_appointments";

    // kiểm tra trùng exact time (có thể mở rộng kiểm tra overlap)
    $sql = "SELECT COUNT(*) FROM " . $table . " WHERE doctor_id = :doctor_id
            AND appointment_date = :date
            AND appointment_time = :time
            AND status IN (0,1)";

    $sth = $db->prepare($sql);
    $sth->bindValue(':doctor_id', (int)$doctor_id, PDO::PARAM_INT);
    $sth->bindValue(':date', $date, PDO::PARAM_STR);
    $sth->bindValue(':time', $time, PDO::PARAM_STR);
    $sth->execute();

    return ($sth->fetchColumn() == 0);
}
