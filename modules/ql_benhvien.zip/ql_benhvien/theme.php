<?php
if (!defined('NV_IS_MOD_QLBENHVIEN')) die('Stop!!!');

function qlbenhvien_theme_example()
{
    return '';
}
