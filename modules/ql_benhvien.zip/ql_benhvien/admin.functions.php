<?php
if (!defined('NV_ADMIN') or !defined('NV_MAINFILE') or !defined('NV_IS_MODADMIN')) die('Stop!!!');

// khai báo hằng để admin/main.php dùng kiểm tra
define('NV_IS_QLBENHVIEN_ADMIN', true);
