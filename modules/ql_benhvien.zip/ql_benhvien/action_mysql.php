<?php

/**
 * @Project NUKEVIET 4.x
 * @Module QL_BENHVIEN
 * @Author Do Dang Hoan
 * @License GNU/GPL version 2 or any later version
 * @Createdate 15/10/2025
 */

if (!defined('NV_IS_FILE_MODULES')) {
    die('Stop!!!');
}

$sql_drop_module = [];
$sql_create_module = [];

// ------------------- DROP TABLES -------------------
$sql_drop_module[] = "DROP TABLE IF EXISTS `" . $db_config['prefix'] . "_ql_benhvien_hosokham`";
$sql_drop_module[] = "DROP TABLE IF EXISTS `" . $db_config['prefix'] . "_ql_benhvien_lichkham`";
$sql_drop_module[] = "DROP TABLE IF EXISTS `" . $db_config['prefix'] . "_ql_benhvien_bacsi`";
$sql_drop_module[] = "DROP TABLE IF EXISTS `" . $db_config['prefix'] . "_ql_benhvien_benhnhan`";
$sql_drop_module[] = "DROP TABLE IF EXISTS `" . $db_config['prefix'] . "_ql_benhvien_chuyenkhoa`";

// ------------------- CREATE TABLES -------------------

// 1️⃣ Chuyên khoa
$sql_create_module[] = "
CREATE TABLE `" . $db_config['prefix'] . "_ql_benhvien_chuyenkhoa` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tenchuyenkhoa` VARCHAR(100) NOT NULL,
  `mota` MEDIUMTEXT DEFAULT NULL,
  `trangthai` TINYINT(4) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

// 2️⃣ Bác sĩ
$sql_create_module[] = "
CREATE TABLE `" . $db_config['prefix'] . "_ql_benhvien_bacsi` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `hoten` VARCHAR(100) NOT NULL,
  `ngaysinh` DATE DEFAULT NULL,
  `gioitinh` TINYINT(4) DEFAULT NULL,
  `chuyenkhoa_id` INT(11) DEFAULT NULL,
  `trinhdo` VARCHAR(100) DEFAULT NULL,
  `lichlamviec` MEDIUMTEXT DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `sdt` VARCHAR(15) DEFAULT NULL,
  `userid` MEDIUMINT(8) UNSIGNED DEFAULT NULL,
  `hinhanh` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_bacsi_chuyenkhoa` (`chuyenkhoa_id`),
  KEY `fk_bacsi_user` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

// 3️⃣ Bệnh nhân
$sql_create_module[] = "
CREATE TABLE `" . $db_config['prefix'] . "_ql_benhvien_benhnhan` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `hoten` VARCHAR(100) NOT NULL,
  `ngaysinh` DATE DEFAULT NULL,
  `gioitinh` TINYINT(4) DEFAULT NULL,
  `diachi` VARCHAR(255) DEFAULT NULL,
  `sdt` VARCHAR(15) DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `userid` MEDIUMINT(8) UNSIGNED DEFAULT NULL,
  `ngaytao` DATETIME DEFAULT CURRENT_TIMESTAMP(),
  PRIMARY KEY (`id`),
  KEY `fk_benhnhan_user` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

// 4️⃣ Lịch khám
$sql_create_module[] = "
CREATE TABLE `" . $db_config['prefix'] . "_ql_benhvien_lichkham` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `benhnhan_id` INT(11) DEFAULT NULL,
  `bacsi_id` INT(11) DEFAULT NULL,
  `ngaykham` DATE NOT NULL,
  `giokham` TIME NOT NULL,
  `trangthai` ENUM('pending','confirmed','cancelled') DEFAULT 'pending',
  `ghichu` MEDIUMTEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_lichkham_benhnhan` (`benhnhan_id`),
  KEY `fk_lichkham_bacsi` (`bacsi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

// 5️⃣ Hồ sơ khám
$sql_create_module[] = "
CREATE TABLE `" . $db_config['prefix'] . "_ql_benhvien_hosokham` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `lichkham_id` INT(11) NOT NULL,
  `ngaykham` DATETIME NOT NULL,
  `chandoan` TEXT DEFAULT NULL,
  `ketqua` TEXT DEFAULT NULL,
  `ketluan` TEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_hosokham_lichkham` (`lichkham_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Lưu kết quả khám của từng lần'";

// ------------------- RÀNG BUỘC KHÓA NGOẠI -------------------
$sql_create_module[] = "
ALTER TABLE `" . $db_config['prefix'] . "_ql_benhvien_bacsi`
  ADD CONSTRAINT `fk_bacsi_chuyenkhoa` FOREIGN KEY (`chuyenkhoa_id`)
  REFERENCES `" . $db_config['prefix'] . "_ql_benhvien_chuyenkhoa` (`id`)
  ON DELETE SET NULL ON UPDATE CASCADE";

$sql_create_module[] = "
ALTER TABLE `" . $db_config['prefix'] . "_ql_benhvien_lichkham`
  ADD CONSTRAINT `fk_lichkham_bacsi` FOREIGN KEY (`bacsi_id`)
  REFERENCES `" . $db_config['prefix'] . "_ql_benhvien_bacsi` (`id`)
  ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_lichkham_benhnhan` FOREIGN KEY (`benhnhan_id`)
  REFERENCES `" . $db_config['prefix'] . "_ql_benhvien_benhnhan` (`id`)
  ON DELETE CASCADE ON UPDATE CASCADE";

$sql_create_module[] = "
ALTER TABLE `" . $db_config['prefix'] . "_ql_benhvien_hosokham`
  ADD CONSTRAINT `fk_hosokham_lichkham` FOREIGN KEY (`lichkham_id`)
  REFERENCES `" . $db_config['prefix'] . "_ql_benhvien_lichkham` (`id`)
  ON DELETE CASCADE ON UPDATE CASCADE";

