<?php
if (!defined('NV_MAINFILE')) die('Stop!!!');

$lang_translator['author'] = 'Do Dang Hoan';
$lang_translator['createdate'] = '15/10/2025';
$lang_translator['langtype'] = 'lang_module';

$lang_module['main'] = 'Quản lý bệnh viện';
$lang_module['dat_lich'] = 'Đặt lịch khám';
$lang_module['manage_schedule'] = 'Quản lý lịch khám';
