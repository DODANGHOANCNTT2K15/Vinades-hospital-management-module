<?php
if (!defined('NV_IS_QLBENHVIEN_ADMIN')) die('Stop!!!');

global $db, $db_config, $lang_module, $module_file;

// lấy 10 lịch mới nhất (demo)
$table_app = $db_config['prefix'] . "_" . NV_LANG_DATA . "_ql_benhvien_appointments";
$sql = "SELECT a.*, d.fullname AS doctor_name FROM " . $table_app . " a
        LEFT JOIN " . $db_config['prefix'] . "_" . NV_LANG_DATA . "_ql_benhvien_doctors d ON a.doctor_id = d.id
        ORDER BY a.created_at DESC LIMIT 0,50";
$rows = $db->query($sql)->fetchAll();

$contents = '<h2>Quản lý Lịch khám</h2>';
$contents .= '<table class="table table-striped"><thead><tr><th>ID</th><th>Bệnh nhân</th><th>Bác sĩ</th><th>Ngày</th><th>Giờ</th><th>Trạng thái</th></tr></thead><tbody>';
foreach ($rows as $r) {
    $status = ($r['status'] == 0) ? 'Chờ' : (($r['status'] == 1) ? 'Xác nhận' : (($r['status']==2)?'Hủy':'Hoàn thành'));
    $contents .= '<tr>';
    $contents .= '<td>' . $r['id'] . '</td>';
    $contents .= '<td>' . htmlspecialchars($r['patient_name']) . '</td>';
    $contents .= '<td>' . htmlspecialchars($r['doctor_name']) . '</td>';
    $contents .= '<td>' . $r['appointment_date'] . '</td>';
    $contents .= '<td>' . $r['appointment_time'] . '</td>';
    $contents .= '<td>' . $status . '</td>';
    $contents .= '</tr>';
}
$contents .= '</tbody></table>';

include NV_ROOTDIR . '/includes/header.php';
echo nv_admin_theme($contents);
include NV_ROOTDIR . '/includes/footer.php';
