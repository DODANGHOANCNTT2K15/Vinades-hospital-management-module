<?php
if (!defined('NV_IS_QLBENHVIEN_ADMIN')) die('Stop!!!');

global $db, $db_config, $lang_module, $nv_Request;

$act = $nv_Request->get_string('act', 'get', 'list');
$contents = '';

if ($act == 'add') {
    // hiển thị form add (đơn giản)
    $contents .= '<h3>Thêm lịch (thủ công)</h3>';
    $contents .= '<form method="post">';
    $contents .= 'Bác sĩ (id): <input name="doctor_id"><br>';
    $contents .= 'Bệnh nhân: <input name="patient_name"><br>';
    $contents .= 'Ngày: <input type="date" name="date"><br>';
    $contents .= 'Giờ: <input type="time" name="time"><br>';
    $contents .= '<button type="submit" name="submit">Thêm</button>';
    $contents .= '</form>';

    if ($nv_Request->isset_request('submit', 'post')) {
        $doctor_id = $nv_Request->get_int('doctor_id', 'post', 0);
        $patient_name = $nv_Request->get_title('patient_name', 'post', '');
        $date = $nv_Request->get_string('date', 'post', '');
        $time = $nv_Request->get_string('time', 'post', '');

        $table = $db_config['prefix'] . "_" . NV_LANG_DATA . "_ql_benhvien_appointments";
        $stmt = $db->prepare("INSERT INTO " . $table . " (doctor_id, patient_name, appointment_date, appointment_time) VALUES (:doctor_id, :patient_name, :date, :time)");
        $stmt->bindValue(':doctor_id', $doctor_id, PDO::PARAM_INT);
        $stmt->bindValue(':patient_name', $patient_name, PDO::PARAM_STR);
        $stmt->bindValue(':date', $date, PDO::PARAM_STR);
        $stmt->bindValue(':time', $time, PDO::PARAM_STR);
        $stmt->execute();

        $contents .= '<p>Đã thêm lịch.</p>';
    }
} else {
    // chuyển về main list
    Header('Location: ' . NV_BASE_ADMINURL . 'index.php?nv=' . $module_name);
    exit;
}

include NV_ROOTDIR . '/includes/header.php';
echo nv_admin_theme($contents);
include NV_ROOTDIR . '/includes/footer.php';
